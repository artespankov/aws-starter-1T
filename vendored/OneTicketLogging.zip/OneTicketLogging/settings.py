"""OneTicketLogging settings."""
from os import getenv

STREAM_REGION = getenv('AWS_REGION', 'us-east-1')
ELASTICSEARCH_STREAM_NAME_BASE = 'elasticsearch-logging-stream'
REQUESTBIN_STREAM_NAME_BASE = 'requestbin-logging-stream'
MINIMUM_STREAM_COUNT = 8  # How many streams there are for sure deployed
CROSS_ACCOUNT_LOGGING_ROLE_ARN = f'arn:aws:iam::405028608951:role/{STREAM_REGION}-LoggingCrossAccount'
APP_NAME = getenv('APP_NAME', 'unnamed')
AWS_BATCH_JOB_ID = getenv('AWS_BATCH_JOB_ID', '')
JOB_ID = getenv('JOB_ID', '')
USER_ID = getenv('USER_ID', '')
IS_PROD = getenv('ENV_TYPE', 'dev') == 'prod'
RUNNING_IN_AWS = bool(getenv('AWS_EXECUTION_ENV') or AWS_BATCH_JOB_ID)

# skip natural LogRecord attributes
# http://docs.python.org/library/logging.html#logrecord-attributes
RESERVED_ATTRS = (
    'args', 'asctime', 'created', 'exc_info', 'exc_text', 'filename', 'funcName', 'levelname', 'levelno', 'lineno',
    'module', 'msecs', 'message', 'msg', 'name', 'pathname', 'process', 'processName', 'relativeCreated',
    'stack_info', 'thread', 'threadName'
)

# 1ticket allowed logging fields:
ALLOWED_KEYS = ['userid', 'listingid', 'remoteid', 'appname', 'orderid', 'invoiceid', 'accountid', 'jobid', 'logurl']
MAX_KEYS = 5
