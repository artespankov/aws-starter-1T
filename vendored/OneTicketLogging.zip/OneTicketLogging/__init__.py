"""Top level exports for ease of access."""
from OneTicketLogging.core.elasticsearch import get_logger as elasticsearch_logger
