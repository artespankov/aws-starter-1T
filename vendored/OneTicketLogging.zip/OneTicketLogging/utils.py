"""Shared utilities."""
from datetime import datetime, timedelta, timezone
from random import choice

from boto3 import client as boto3_client, Session as boto3_Session

from OneTicketLogging.settings import (
    RUNNING_IN_AWS, STREAM_REGION, ELASTICSEARCH_STREAM_NAME_BASE, REQUESTBIN_STREAM_NAME_BASE, MINIMUM_STREAM_COUNT,
    APP_NAME, CROSS_ACCOUNT_LOGGING_ROLE_ARN
)

if RUNNING_IN_AWS:
    STS = boto3_client('sts')
else:
    STS = boto3_Session(profile_name='1ticketdev').client('sts')


class Firehose:
    def __init__(self):
        self.credentials = None
        self.client = None
        self.elasticsearch_streams = []
        self.requestbin_streams = []
        self.check_or_set_client()
        self.get_streams()

    def check_or_set_client(self):
        if not self.credentials or not self.credentials_valid():
            self.credentials = STS.assume_role(
                RoleArn=CROSS_ACCOUNT_LOGGING_ROLE_ARN,
                RoleSessionName=APP_NAME
            )['Credentials']
            self.client = boto3_client(
                'firehose', region_name=STREAM_REGION, aws_access_key_id=self.credentials['AccessKeyId'],
                aws_secret_access_key=self.credentials['SecretAccessKey'],
                aws_session_token=self.credentials['SessionToken']
            )

    def get_streams(self):
        """Get list of active logging streams."""
        try:
            streams = self.client.list_delivery_streams()['DeliveryStreamNames']
            self.elasticsearch_streams = [stream for stream in streams if ELASTICSEARCH_STREAM_NAME_BASE in stream]
            self.requestbin_streams = [stream for stream in streams if REQUESTBIN_STREAM_NAME_BASE in stream]
        except:
            # Rate limit on ListDeliveryStreams, or any other error, don't want to fail here
            # Fall back to known streams
            self.elasticsearch_streams = [
                f'{ELASTICSEARCH_STREAM_NAME_BASE}-{i}' for i in range(0, MINIMUM_STREAM_COUNT)
            ]
            self.requestbin_streams = [f'{REQUESTBIN_STREAM_NAME_BASE}-{i}' for i in range(0, MINIMUM_STREAM_COUNT)]

    def credentials_valid(self):
        """Check expiration of credentials."""
        return (self.credentials['Expiration'] - timedelta(minutes=10)) > datetime.now(timezone.utc)

    def put_record(self, data, log_type):
        """Put record to random choice from delivery streams."""
        self.check_or_set_client()
        if log_type == 'elasticsearch':
            stream = choice(self.elasticsearch_streams)
        elif log_type == 'requestbin':
            stream = choice(self.requestbin_streams)
        else:
            raise ValueError('Invalid log type!')
        try:
            self.client.put_record(
                Record={'Data': data},
                DeliveryStreamName=stream
            )
        except Exception as exc:
            print(exc)


# Instantiate global firehose client
FIREHOSE_CLIENT = Firehose()
